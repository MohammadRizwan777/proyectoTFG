package com.example.miproyectotfgv2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.miproyectotfgv2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflar el layout con ViewBinding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Aquí puedes agregar listeners o lógica de la actividad
    }
}
